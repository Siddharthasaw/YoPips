

import React from 'react';  
import FAQ from '@/components/FAQ';
 const FaqPage = () => {
    return (
      <>
         <FAQ />
      </>
    );
 }

 export default FaqPage;