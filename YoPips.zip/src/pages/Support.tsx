import React from "react";

import ContactForm from "@/components/ContactForm";

const Support = () => {
  return (
    
     <>
        <ContactForm />
     </>
  );
};

export default Support;