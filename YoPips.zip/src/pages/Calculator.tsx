import ProfitCalculator from "@/components/ProfitCalculator";

const Calculator = () => {
  return (
   <>
      <ProfitCalculator />
   </>
  );
};

export default Calculator; // Ensure this line is present